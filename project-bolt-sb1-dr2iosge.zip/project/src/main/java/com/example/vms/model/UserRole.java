package com.example.vms.model;

public enum UserRole {
    ADMIN,
    HOST,
    SECURITY
}