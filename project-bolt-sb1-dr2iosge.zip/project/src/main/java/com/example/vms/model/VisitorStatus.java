package com.example.vms.model;

public enum VisitorStatus {
    PRE_REGISTERED,
    CHECKED_IN,
    CHECKED_OUT,
    CANCELED
}