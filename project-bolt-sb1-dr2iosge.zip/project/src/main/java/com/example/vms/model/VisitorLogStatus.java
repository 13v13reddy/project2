package com.example.vms.model;

public enum VisitorLogStatus {
    EXPECTED,
    CHECKED_IN,
    CHECKED_OUT,
    CANCELED
}